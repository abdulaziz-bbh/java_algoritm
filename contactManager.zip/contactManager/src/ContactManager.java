import java.util.Scanner;

public class ContactManager {

    Contact[] contactArr = new Contact[10];
    int currentIndex = 0;


    public void start(){
        boolean b = true;
        while(b){
            menu();
            int n = getMenuNumber();
            switch (n){
                case 1:
                    Contact contact = addContact();
                    addToArray(contact);

                    break;
                case 2:
                    printContactList();
                    break;
                case 3:
                    String query = getQuery();
                    search(query);
                    break;
                case 4:
                    String phone = deleteContact();
                    deleteContactFromArray(phone);
                    break;
                case 0:
                    b = false;
                    break;
                default:
                    System.out.println("Please choose correct number!. ");
            }
        }
    }

    public  void menu(){
        System.out.println("** Menu **");
        System.out.println("1. Add Contact");
        System.out.println("2. Show List");
        System.out.println("3. Search ");
        System.out.println("4. Delete contact");
        System.out.println("0. Exit");
    }

    public  void addToArray(Contact contact){
        if (!isValidContact(contact)){
            return;
        }
        if (isPhoneExist(contact.phone)){
            System.out.println("Phone number exists mazgi.");
            return;
        }
        if (currentIndex == contactArr.length){
            Contact[] newArr = new Contact[contactArr.length * 2];
            for (int i = 0; i < contactArr.length; i++) {
                newArr[i] =contactArr[i];
            }
            contactArr = newArr;
            System.out.println("New Array created");
        }
        contactArr[currentIndex] = contact;
        currentIndex++;
        System.out.println("Contact Added.");
    }

    public  void printContactList(){
        for (Contact c : contactArr){
            if (c != null){
                System.out.println(c.name + " " + c.surname+ " " + c.phone);
            }
        }
    }

    public  String getQuery(){
        System.out.println("Enter query: ");
        Scanner scanner = new Scanner(System.in);
        return scanner.next();
    }

    public  void search(String query){
        query = query.toLowerCase();
        for (Contact contact : contactArr) {
            if (contact == null){
                continue;
            }
            if (contact.name.toLowerCase().contains(query) ||contact.surname.toLowerCase().contains(query)
                    || contact.phone.contains(query)){
                System.out.println(contact.name+" " + contact.surname+" "
                        +contact.phone);
            }
        }
    }


    public  int getMenuNumber(){
        System.out.println("Choose menu: ");
        Scanner scanner = new Scanner(System.in);
        return scanner.nextInt();
    }

    public  Contact addContact(){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter name: ");
        String name = scanner.next();
        System.out.println("Enter surname: ");
        String surname = scanner.next();
        System.out.println("Enter phone: ");
        String phone = scanner.next();
        Contact contact = new Contact();
        contact.name = name;
        contact.surname = surname;
        contact.phone = phone;
        return contact;
    }

    public  Boolean isValidContact(Contact contact){
        if(contact.name == null || contact.name.trim().length() < 3){
            System.out.println("Contact name is wrong");
            return false;
        }
        if (contact.surname == null || contact.surname.trim().length() < 3){
            System.out.println("Contact surname is wrong");
            return false;
        }
        if (contact.phone == null || contact.phone.trim().length() != 12 ||
                !contact.phone.startsWith("998")){
            System.out.println("Contact phone number is wrong");
            return false;
        }
        char [] phoneArr = contact.phone.toCharArray();
        for (char c : phoneArr) {
            if(!Character.isDigit(c)){
                System.out.println("Contact phone is wrong");
                return false;
            }
        }
        return true;
    }

    public  boolean isPhoneExist(String phone){
        for (Contact contact : contactArr) {
            if(contact != null){
                if (contact.phone.equals(phone)){
                    return true;
                }
            }
        }
        return false;
    }

    public  String deleteContact(){
        System.out.println("Enter phone: ");
        Scanner scanner = new Scanner(System.in);
        return scanner.next();
    }

    public  void deleteContactFromArray(String phone){
        for (int i = 0;i < contactArr.length;i++) {
            Contact contact = contactArr[i];
            if (contact != null && contact.phone.equals(phone)){
                contactArr[i] = null;
                System.out.println("Contact deleted");
                break;
            }
        }
    }




}
